<div ng-app="nodelist">
  <div ng-view></div>
</div>